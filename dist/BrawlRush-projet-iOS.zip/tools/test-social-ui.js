/* Test de l'interface des comptes en ligne (2 téléphones, serveur réel, Supabase imité) : connexion, identifiant, demande d'ami
   par identifiant, acceptation, présence, modification d'identifiant, cadeau du développeur, mode classé (fermé / accès anticipé).
   Usage : node tools/test-social-ui.js [dossier_captures] */
'use strict';
const { chromium } = require('playwright'); const { spawn } = require('child_process'); const path = require('path'), os = require('os');
const MOCK = 54391, OUT = process.argv[2] || os.tmpdir();
process.env.SUPABASE_URL = 'http://127.0.0.1:' + MOCK; process.env.SUPABASE_SECRET = 'service-test-key';
process.env.DEV_EMAILS = 'dev@test.fr'; process.env.RANKED_AT = new Date(Date.now() + 5 * 3600e3).toISOString();
process.env.DATA_DIR = path.join(os.tmpdir(), 'brsui' + Date.now());
const GAME = 'file://' + path.resolve(__dirname, '../app/src/main/assets/www/index.html');
let fails = 0; const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) fails++; };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
(async () => {
  const mock = spawn('node', [path.join(__dirname, 'supabase-mock.js'), String(MOCK)], { stdio: 'ignore' }); await sleep(700);
  const S = require('../server/server.js'); await new Promise((r) => S.server.listen(0, r)); const port = S.server.address().port;
  const api = async (p, b) => (await fetch('http://127.0.0.1:' + MOCK + p, { method: 'POST', headers: { apikey: 'anon-test-key', 'content-type': 'application/json' }, body: JSON.stringify(b) })).json();
  await api('/auth/v1/signup', { email: 'dev@test.fr', password: 'secret123', data: { username: 'DevBoss' } });
  await api('/auth/v1/signup', { email: 'bob@test.fr', password: 'secret123', data: { username: 'Bob' } });
  await api('/auth/v1/signup', { email: 'carl@test.fr', password: 'secret123', data: { username: 'Carl' } });
  const b = await chromium.launch(); const errs = [];
  async function phone(name, email) {
    const ctx = await b.newContext({ viewport: { width: 844, height: 390 }, deviceScaleFactor: 2 });
    await ctx.route(/supabase\.co\//, async (route) => { // le vrai projet est remplacé par l'imitation locale
      const r = route.request(), u = new URL(r.url()), h = Object.assign({}, r.headers(), { apikey: 'anon-test-key' });
      const res = await route.fetch({ url: 'http://127.0.0.1:' + MOCK + u.pathname + u.search, headers: h }); await route.fulfill({ response: res });
    });
    await ctx.addInitScript(() => localStorage.setItem('brawlrush_save_v1', JSON.stringify({ tutorialDone: true, lastDaily: 99999999, gems: 50, settings: { quality: 'medium', sound: false, music: false, vibrate: false, aimAssist: true, lefty: false } })));
    const p = await ctx.newPage(); p.on('pageerror', (e) => errs.push(name + ': ' + e.message));
    await p.goto(GAME + '?server=127.0.0.1:' + port); await p.waitForTimeout(2500); await p.mouse.click(422, 200); await p.waitForTimeout(800);
    if (!(await p.isVisible('#accBody'))) await p.evaluate(() => G.UI.accountModal('login'));
    await p.click('[data-act=accTab][data-k=login]', { force: true }); await p.fill('#acc_id', email); await p.fill('#acc_pass', 'secret123'); await p.click('[data-act=accLogin]', { force: true });
    for (let i = 0; i < 40 && !(await p.evaluate(() => !!(G.Net.me && G.Net.fr))); i++) await sleep(250);
    await p.evaluate(() => { while (G.UI.modals.length) G.UI.closeModal(); });
    return p;
  }
  const D = await phone('Dev', 'dev@test.fr'), B = await phone('Bob', 'bob@test.fr');
  const md = await D.evaluate(() => G.Net.me), mb = await B.evaluate(() => G.Net.me);
  ok(md && /^[A-Z]{4,16}$/.test(md.handle) && md.dev === true, 'connexion du compte développeur : identifiant ' + (md && md.handle) + ', droits développeur reconnus');
  ok(mb && /^[A-Z]{4,16}$/.test(mb.handle) && !mb.dev, 'connexion de Bob : identifiant ' + (mb && mb.handle));
  ok(await D.evaluate(() => !!(G.DevReady && G.Dev && document.getElementById('devBtn') && document.getElementById('devGiftBtn'))), 'compte développeur : menu DEV (outils + cadeaux) activé automatiquement à la connexion');
  ok(await B.evaluate(() => !G.Dev && !document.getElementById('devBtn')), 'compte normal : pas de menu DEV');
  B.clear && 0; await B.evaluate(() => G.Net.send({ t: 'dv_sim', act: 'join' })); await sleep(300); ok(await B.evaluate(() => !(G.Net.party && G.Net.party.members.length > 1)), 'compte normal : outils développeur refusés par le serveur même en envoyant la commande');
  await B.evaluate(() => G.UI.ACT.settings()); await sleep(300);
  ok((await B.textContent('.modal')).includes('bob@test.fr'), 'réglages d\'un compte normal : diagnostic avec l\'e-mail du compte');
  await B.evaluate(() => { while (G.UI.modals.length) G.UI.closeModal(); });
  await D.click('#devBtn', { force: true }); await sleep(500);
  ok(await D.evaluate(() => !!G.DevPro.panel && !!document.querySelector('.rg-hd .rg-hb.purple') && document.querySelectorAll('.rg-side .rg-cat').length === 5 && document.querySelectorAll('.rg-card').length >= 10), 'menu développeur : interface verre sombre (en-tête, catégories, onglets, cartes OUI/NON)');
  await D.screenshot({ path: path.join(OUT, 'dev_1_accueil.png') });
  const card = async (g, id) => { await D.evaluate(() => { G.DevPro.ui.detail = null; G.DevPro.ui.search = false; G.DevPro.ui.view = 'lib'; }); await D.click('.rg-cat[data-g=' + g + ']', { force: true }); await sleep(150); await D.click('.rg-card[data-card=' + id + ']', { force: true }); await sleep(300); };
  await D.click('[data-sbtn]', { force: true }); await D.fill('#rgQ', 'inactivit'); await sleep(300); ok(await D.evaluate(() => !!document.querySelector('.rg-card[data-card=livecfg]')), 'recherche : trouve « Paramètres en direct » (délai d\'inactivité)');
  await D.click('.rg-cat[data-g=battle]', { force: true }); await sleep(150); await D.click('.rg-card[data-card=god]', { force: true }); await sleep(150);
  ok(await D.evaluate(() => G.Dev.cfg.god === true && document.querySelector('.rg-card[data-card=god]').classList.contains('on')), 'carte « Invincible » : un toucher → OUI (bordure blanche)');
  await D.click('.rg-card[data-card=god]', { force: true });
  await card('online', 'simgroup'); await D.click('[data-s=join]', { force: true }); await sleep(700);
  ok(await D.evaluate(() => G.Net.party && G.Net.party.members.length === 2 && G.Net.party.members[1].test), 'E. joueur de test ajouté à mon équipe par le serveur');
  await card('online', 'livecfg');
  await D.evaluate(() => { const r = document.querySelector('input[data-r=afkSec]'); r.value = 60; r.dispatchEvent(new Event('input', { bubbles: true })); });
  await D.click('[data-a=cfgApply]', { force: true }); await sleep(500); ok(S.CFG.afkSec === 60, 'E. paramètre en direct appliqué sur le serveur (inactivité 60 s)');
  await card('online', 'simgroup'); await D.click('[data-s=clear]', { force: true }); await sleep(300);
  await D.screenshot({ path: path.join(OUT, 'dev_2_multijoueur.png') });
  await card('display', 'diag_live'); await sleep(800); ok(await D.isVisible('#dpKpis') && /FPS/.test(await D.textContent('#dpKpis')), 'D. diagnostics en direct (FPS, ping, pertes, mémoire, erreurs, synchro)');
  await card('online', 'testprof'); await D.click('[data-a=tpNew]', { force: true }); await sleep(400);
  const tp = await D.evaluate(() => ({ banner: !!document.getElementById('tpBanner') }));
  ok(tp.banner, 'F. profil de test actif (bandeau visible)');
  await card('online', 'teststats'); await D.click('[data-a=coins]', { force: true }); await D.evaluate(() => G.Account.push(true)); await sleep(400);
  const cloud = await fetch('http://127.0.0.1:' + MOCK + '/_test/profiles').then((r) => r.json()).catch(() => null);
  const devRow = cloud && (Array.isArray(cloud) ? cloud : Object.values(cloud)).find((r) => r.username === 'DevBoss');
  ok(!devRow || !devRow.save || (devRow.save.coins || 0) < 10000, 'F. profil de test : rien n\'est envoyé dans le cloud du vrai compte');
  await card('online', 'testprof'); await D.click('[data-a=tpReal]', { force: true }); await sleep(400); ok(await D.evaluate(() => !document.getElementById('tpBanner') && G.Save.data.coins < 10000), 'F. retour au vrai profil (progression intacte)');
  await card('misc', 'mapedit'); await sleep(200);
  const cv = await D.evaluate(() => { const c = document.querySelector('#meCv').getBoundingClientRect(); return { x: c.x, y: c.y, w: c.width, h: c.height }; });
  await D.click('[data-tool="4"]', { force: true }); await sleep(100);
  await D.mouse.move(cv.x + cv.w * 0.35, cv.y + cv.h * 0.45); await D.mouse.down(); await D.mouse.move(cv.x + cv.w * 0.42, cv.y + cv.h * 0.45, { steps: 4 }); await D.mouse.up(); await sleep(150);
  await D.screenshot({ path: path.join(OUT, 'dev_3_cartes.png') });
  await D.click('[data-a=mePlay]', { force: true }); await sleep(1500);
  ok(await D.evaluate(() => G.App.state === 'match' && G.App.M.mapKey === 'dev_custom' && [...G.App.M.map.tiles].some((t) => t === 4)), 'C. carte peinte jouable immédiatement (eau ajoutée)');
  ok(await D.evaluate(() => { const q = document.getElementById('rgQuick'); return !!q && !q.hidden; }), 'en partie : « Accès rapide » + FPS affichés');
  await D.evaluate(() => { G.App.quitMatch(); while (G.UI.modals.length) G.UI.closeModal(); G.UI.hideAll(); G.UI.show('home'); }); await sleep(500);
  await D.evaluate(() => G.DevPro.open()); await card('misc', 'autotests'); await D.click('[data-a=autoTest]', { force: true });
  for (let i = 0; i < 80 && !(await D.evaluate(() => G.DevPro.tests.length && Date.now() - G.DevPro.tests[0].at < 120000)); i++) await sleep(500);
  const at = await D.evaluate(() => G.DevPro.tests[0]);
  ok(at && at.ok >= at.n - 1, 'G. tests automatiques : ' + (at ? at.ok + '/' + at.n + ' réussis (' + at.res.filter((r) => !r.ok).map((r) => r.name + ': ' + r.d).join(', ') + ')' : 'aucun'));
  await D.screenshot({ path: path.join(OUT, 'dev_4_avance.png') });
  await D.evaluate(() => G.DevPro.close());
  // Bob ajoute le développeur par son identifiant
  await B.evaluate(() => { G.UI.socialTab = 'friends'; G.UI.frTab = 'add'; G.UI.show('social'); }); await sleep(600);
  await B.fill('#frIn', md.handle.toLowerCase()); await B.click('[data-act=frSearch]', { force: true }); await sleep(700);
  for (let i = 0; i < 20 && !(await B.isVisible('#frRes [data-act=frReq]')); i++) await sleep(250);
  ok(await B.isVisible('#frRes [data-act=frReq]'), 'recherche par identifiant : profil trouvé avec « Demander en ami »');
  await B.screenshot({ path: path.join(OUT, 'soc_add.png') });
  await B.click('#frRes [data-act=frReq]', { force: true }); await sleep(800);
  ok(await B.evaluate(() => G.Net.fr.outgoing.length === 1), 'demande envoyée (catégorie « envoyées »)');
  await D.evaluate(() => { G.UI.socialTab = 'friends'; G.UI.frTab = 'req'; G.UI.show('social'); }); await sleep(600);
  ok(await D.isVisible('[data-act=frAccept]'), 'le développeur voit la demande reçue (Accepter / Refuser)');
  await D.screenshot({ path: path.join(OUT, 'soc_req.png') });
  await D.click('[data-act=frAccept]', { force: true }); await sleep(800);
  await D.evaluate(() => { G.UI.frTab = 'list'; G.UI.renderSocial(); }); await sleep(400);
  ok(await D.evaluate(() => { const f = G.Net.fr.friends[0]; return f && f.name === 'Bob' && f.status === 'menu'; }), 'amis : Bob apparaît « Disponible »');
  await D.screenshot({ path: path.join(OUT, 'soc_list.png') });
  // Bob modifie son identifiant depuis son profil
  await B.evaluate(() => { G.UI.show('home'); G.UI.ACT.profile(); }); await sleep(900);
  ok(await B.isVisible('.pf-id [data-act=handleEdit]'), 'profil : identifiant affiché avec « Copier » et « Modifier »');
  await B.screenshot({ path: path.join(OUT, 'soc_profile.png') });
  await B.click('.pf-id [data-act=handleEdit]', { force: true }); await sleep(300); await B.fill('#hdIn', 'loupgivre'); await B.click('[data-act=handleSave]', { force: true }); await sleep(900);
  ok(await B.evaluate(() => G.Net.me.handle === 'LOUPGIVRE' && !G.Net.me.canHandle), 'identifiant modifié (LOUPGIVRE) puis verrouillé');
  // cadeau du développeur
  await D.evaluate(() => { while (G.UI.modals.length) G.UI.closeModal(); G.UI.show('home'); G.UI.devPanel(); }); await sleep(400);
  await D.fill('#dvIn', 'bob'); await D.click('[data-act=dvSearch]', { force: true }); await sleep(800); // recherche par pseudo
  ok(await D.isVisible('.dv-b[data-id=yeti]'), 'panneau développeur : profil du joueur + liste des brawlers à offrir');
  await D.screenshot({ path: path.join(OUT, 'soc_dev.png') });
  await B.evaluate(() => { while (G.UI.modals.length) G.UI.closeModal(); });
  await D.click('.dv-b[data-id=yeti]', { force: true }); await sleep(1200);
  ok(await B.evaluate(() => G.Save.data.unlocked.includes('yeti') && !!document.querySelector('.giftm')), 'Bob reçoit le cadeau (fenêtre + Yéti débloqué dans sa sauvegarde)');
  await B.screenshot({ path: path.join(OUT, 'soc_gift.png') });
  // classé
  await B.evaluate(() => { while (G.UI.modals.length) G.UI.closeModal(); G.UI.ranked(); }); await sleep(1000);
  ok(await B.isVisible('.rk-lock') && !(await B.isVisible('[data-act=rkPlay]')), 'classé fermé pour un joueur : compte à rebours jusqu\'à l\'ouverture');
  await B.screenshot({ path: path.join(OUT, 'soc_ranked_lock.png') });
  await D.evaluate(() => { while (G.UI.modals.length) G.UI.closeModal(); G.UI.ranked(); }); await sleep(1000);
  ok(await D.isVisible('[data-act=rkPlay]') && await D.isVisible('.rk-early'), 'classé ouvert en avant-première pour le compte développeur');
  await D.screenshot({ path: path.join(OUT, 'soc_ranked_dev.png') });
  // fiche d'un joueur ouverte depuis le journal des combats : ajouter / accepter / déjà amis, mise à jour en direct
  const C = await phone('Carl', 'carl@test.fr'); const mc = await C.evaluate(() => G.Net.me);
  await C.evaluate((h) => G.UI.playerCard({ c: h, n: 'Bob', b: 'rex' }), await B.evaluate(() => G.Net.me.handle)); await sleep(900);
  ok(await C.isVisible('.pcard [data-act=frReq]'), 'fiche joueur (journal des combats) : bouton « Ajouter en ami »');
  await C.click('.pcard [data-act=frReq]', { force: true }); await sleep(1000);
  ok(/Demande envoyée/.test(await C.textContent('#pcActs')) && await C.isVisible('[data-act=frCancelCard]'), 'après l\'envoi : « Demande envoyée » (+ Annuler), sans recharger');
  await B.evaluate(() => { while (G.UI.modals.length) G.UI.closeModal(); }); await B.evaluate((h) => G.UI.playerCard({ c: h, n: 'Carl', b: 'sherry' }), mc.handle); await sleep(900);
  ok(await B.isVisible('.pcard [data-act=frAcceptCard]'), 'chez Bob : « Vous a demandé en ami » + Accepter');
  await B.click('.pcard [data-act=frAcceptCard]', { force: true }); await sleep(1200);
  ok(/Déjà amis/.test(await B.textContent('#pcActs')) && /Déjà amis/.test(await C.textContent('#pcActs')), 'demande acceptée : les deux fiches affichent « Déjà amis » automatiquement');
  ok(await C.evaluate(() => (G.Net.fr.friends || []).some((f) => f.name === 'Bob')), 'liste d\'amis mise à jour automatiquement');
  await C.screenshot({ path: path.join(OUT, 'soc_card_amis.png') });
  // un seul appareil par compte : Bob se connecte sur un 2e téléphone
  const B2 = await phone('Bob-2', 'bob@test.fr'); await sleep(1200);
  ok(await B.evaluate(() => !G.Account.loggedIn() && /ouverte ailleurs/.test(document.body.textContent)), 'Bob sur un 2e appareil : le 1er est déconnecté avec un message');
  ok(await B2.evaluate(() => G.Account.loggedIn() && !!G.Net.me), 'le nouvel appareil reste connecté');
  await B.screenshot({ path: path.join(OUT, 'soc_session_ailleurs.png') });
  console.log(errs.length ? 'ERREURS JS : ' + errs.join(' | ') : 'aucune erreur JS');
  await b.close(); mock.kill(); process.exit(fails ? 1 : 0);
})().catch((e) => { console.error('ERREUR', e.message); process.exit(2); });
